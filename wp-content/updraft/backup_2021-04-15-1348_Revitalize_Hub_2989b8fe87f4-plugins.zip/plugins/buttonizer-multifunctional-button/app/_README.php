<?php

/* 
 * SOFTWARE LICENSE INFORMATION
 * 
 * Copyright (c) 2017 Buttonizer, all rights reserved.
 * 
 * This file is part of Buttonizer
 * 
 * For detailed information regarding to the licensing of
 * this software, please review the license.txt or visit:
 * https://buttonizer.pro/license/
 * 
 ****************************************************************************************
 
    ===========================================================================

    Dear reader,

    When you are here, it means you are searching something. Right?

    Something wrong? Error? Or just curious?

    If you want to get a free license, you are here on the wrong place. Please
    buy your license here:
    /wp-admin/admin.php?page=Buttonizer-pricing

    Questons? www.buttonizer.pro

    Need support? Contact us on support@buttonizer.pro

    Have you also checked our knowledge base or community?

    Buttonizer Community: https://community.buttonizer.pro

    Buttonizer Knowledge base: https://community.buttonizer.pro/knowledgebase

    ===========================================================================*/
